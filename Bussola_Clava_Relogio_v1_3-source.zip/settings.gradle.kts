rootProject.name = "BussolaLendaria"
