\
# Bússola + Clava + Relógio Lendários — versão 1.3.0

- `/bussola`: recebe a bússola. Botão direito abre cabeças dos jogadores online; escolha uma para rastrear.
- `/clava`: recebe a clava. Ao acertar outro jogador, ativa impulso vertical inspirado em Carga de Vento. Segurando a clava, não recebe dano de queda.
- `/relogio`: recebe o relógio. Botão direito abre cabeças dos jogadores online; escolha uma para usar o nome no display, chat e TAB.
- `/sem_disfarce`: restaura o nome original.

IMPORTANTE: esta versão altera o nome exibido, chat e TAB. Ela NÃO troca a skin do jogador. Para trocar a skin de verdade no Paper, é necessário integrar e instalar uma biblioteca/plugin de disfarce compatível (por exemplo, LibsDisguises), o que não está incluído neste ZIP. O UUID/login real e os registros do servidor continuam sendo os do jogador original.
Este ZIP é código-fonte, não um JAR compilado. Compile pelo GitHub Actions.
