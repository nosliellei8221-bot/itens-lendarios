package br.creativesquad.bussola;

import net.kyori.adventure.text.Component;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class BussolaLendaria extends JavaPlugin implements Listener {
    private final Map<UUID, UUID> targets = new HashMap<>();
    private final Map<UUID, Long> maceCooldown = new HashMap<>();
    private final Map<UUID, String> disguises = new HashMap<>();
    private final Map<UUID, Component> originalDisplayNames = new HashMap<>();
    private final Map<UUID, Component> originalTabNames = new HashMap<>();
    private static final Component MENU_TITLE = Component.text("Bússola Lendária - jogadores");
    private static final Component COMPASS_NAME = Component.text("Bússola Lendária");
    private static final Component MACE_NAME = Component.text("Clava Lendária");
    private static final Component CLOCK_NAME = Component.text("Relógio Lendário");
    private static final Component CLOCK_MENU_TITLE = Component.text("Relógio Lendário - escolher aparência");

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("bussola") != null) getCommand("bussola").setExecutor(this);
        if (getCommand("clava") != null) getCommand("clava").setExecutor(this);
        if (getCommand("relogio") != null) getCommand("relogio").setExecutor(this);
        if (getCommand("sem_disfarce") != null) getCommand("sem_disfarce").setExecutor(this);
        Bukkit.getScheduler().runTaskTimer(this, this::updateTrackers, 1L, 5L);
        getLogger().info("Bússola e Clava Lendárias ativadas.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores podem usar este comando.");
            return true;
        }
        ItemStack item;
        if (command.getName().equalsIgnoreCase("sem_disfarce")) {
            disguises.remove(player.getUniqueId());
            Component display = originalDisplayNames.remove(player.getUniqueId());
            Component tab = originalTabNames.remove(player.getUniqueId());
            if (display != null) player.displayName(display);
            if (tab != null) player.playerListName(tab);
            player.sendMessage(Component.text("Disfarce removido."));
            return true;
        }
        if (command.getName().equalsIgnoreCase("bussola")) {
            item = namedItem(Material.COMPASS, COMPASS_NAME);
            player.getInventory().addItem(item);
            player.sendMessage(Component.text("Você recebeu a Bússola Lendária!"));
        } else if (command.getName().equalsIgnoreCase("clava")) {
            item = namedItem(Material.MACE, MACE_NAME);
            player.getInventory().addItem(item);
            player.sendMessage(Component.text("Você recebeu a Clava Lendária!"));
        } else if (command.getName().equalsIgnoreCase("relogio")) {
            item = namedItem(Material.CLOCK, CLOCK_NAME);
            player.getInventory().addItem(item);
            player.sendMessage(Component.text("Você recebeu o Relógio Lendário!"));
        }
        return true;
    }

    private ItemStack namedItem(Material material, Component name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(name);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onCompassUse(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
            event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isNamed(event.getItem(), Material.COMPASS, COMPASS_NAME)) return;
        event.setCancelled(true);
        openPlayerMenu(event.getPlayer());
    }

    @EventHandler
    public void onClockUse(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
            event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isNamed(event.getItem(), Material.CLOCK, CLOCK_NAME)) return;
        event.setCancelled(true);
        openDisguiseMenu(event.getPlayer());
    }

    private void openDisguiseMenu(Player viewer) {
        Inventory menu = Bukkit.createInventory(null, 54, CLOCK_MENU_TITLE);
        int slot = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (target.getUniqueId().equals(viewer.getUniqueId())) continue;
            if (slot >= menu.getSize()) break;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(target);
            meta.displayName(Component.text(target.getName()));
            head.setItemMeta(meta);
            menu.setItem(slot++, head);
        }
        if (slot == 0) {
            viewer.sendMessage(Component.text("Não há outros jogadores online."));
            return;
        }
        viewer.openInventory(menu);
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        String alias = disguises.get(event.getPlayer().getUniqueId());
        if (alias != null) {
            event.renderer((source, sourceDisplayName, message, viewer) ->
                    Component.text(alias + ": ").append(message));
        }
    }

    // A Clava ativa o impulso quando acerta outro jogador: não usa clique direito.
    @EventHandler
    public void onClavaHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (!isNamed(attacker.getInventory().getItemInMainHand(), Material.MACE, MACE_NAME)) return;

        long now = System.currentTimeMillis();
        long readyAt = maceCooldown.getOrDefault(attacker.getUniqueId(), 0L);
        if (now < readyAt) return;

        Vector look = attacker.getLocation().getDirection().setY(0);
        if (look.lengthSquared() > 0.0001) look.normalize().multiply(0.25);
        look.setY(1.05);
        attacker.setVelocity(look);
        attacker.setFallDistance(0);
        attacker.getWorld().spawnParticle(Particle.CLOUD,
                attacker.getLocation().add(0, 0.3, 0), 30, 0.55, 0.2, 0.55, 0.06);
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1f, 1f);
        attacker.sendActionBar(Component.text("Carga de Vento!"));
        maceCooldown.put(attacker.getUniqueId(), now + 2500L);
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (isNamed(player.getInventory().getItemInMainHand(), Material.MACE, MACE_NAME) ||
            isNamed(player.getInventory().getItemInOffHand(), Material.MACE, MACE_NAME)) {
            event.setCancelled(true);
            player.setFallDistance(0);
        }
    }

    private boolean isNamed(ItemStack item, Material type, Component name) {
        return item != null && item.getType() == type &&
                item.hasItemMeta() && name.equals(item.getItemMeta().displayName());
    }

    private void openPlayerMenu(Player viewer) {
        Inventory menu = Bukkit.createInventory(null, 54, MENU_TITLE);
        int slot = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (slot >= menu.getSize()) break;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(target);
            meta.displayName(Component.text(target.getName()));
            head.setItemMeta(meta);
            menu.setItem(slot++, head);
        }
        if (slot == 0) {
            viewer.sendMessage(Component.text("Não há jogadores online."));
            return;
        }
        viewer.openInventory(menu);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player viewer)) return;

        if (event.getView().title().equals(CLOCK_MENU_TITLE)) {
            event.setCancelled(true);
            if (event.getClickedInventory() == null ||
                event.getClickedInventory() != event.getView().getTopInventory()) return;
            ItemStack chosen = event.getCurrentItem();
            if (chosen == null || chosen.getType() != Material.PLAYER_HEAD ||
                !(chosen.getItemMeta() instanceof SkullMeta chosenMeta) ||
                chosenMeta.getOwningPlayer() == null) return;

            Player target = Bukkit.getPlayer(chosenMeta.getOwningPlayer().getUniqueId());
            if (target == null || !target.isOnline()) {
                viewer.sendMessage(Component.text("Esse jogador não está mais online."));
                viewer.closeInventory();
                return;
            }

            originalDisplayNames.putIfAbsent(viewer.getUniqueId(), viewer.displayName());
            originalTabNames.putIfAbsent(viewer.getUniqueId(), viewer.playerListName());
            disguises.put(viewer.getUniqueId(), target.getName());
            viewer.displayName(Component.text(target.getName()));
            viewer.playerListName(Component.text(target.getName()));
            viewer.sendMessage(Component.text("Disfarce de nome ativado: " + target.getName()));
            viewer.closeInventory();
            return;
        }

        if (!event.getView().title().equals(MENU_TITLE)) return;
        event.setCancelled(true);

        if (event.getClickedInventory() == null ||
            event.getClickedInventory() != event.getView().getTopInventory()) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() != Material.PLAYER_HEAD) return;
        if (!(clicked.getItemMeta() instanceof SkullMeta meta) || meta.getOwningPlayer() == null) return;

        Player target = Bukkit.getPlayer(meta.getOwningPlayer().getUniqueId());
        if (target == null || !target.isOnline()) {
            viewer.sendMessage(Component.text("Esse jogador não está mais online."));
            viewer.closeInventory();
            return;
        }
        targets.put(viewer.getUniqueId(), target.getUniqueId());
        viewer.sendMessage(Component.text("Bússola rastreando: " + target.getName()));
        viewer.playSound(viewer.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.3f);
        viewer.closeInventory();
        updateOne(viewer, target);
    }

    private void updateTrackers() {
        for (Map.Entry<UUID, UUID> entry : new HashMap<>(targets).entrySet()) {
            Player viewer = Bukkit.getPlayer(entry.getKey());
            Player target = Bukkit.getPlayer(entry.getValue());
            if (viewer == null || !viewer.isOnline()) {
                targets.remove(entry.getKey());
                continue;
            }
            if (target == null || !target.isOnline()) {
                viewer.sendMessage(Component.text("O jogador rastreado saiu. Clique na bússola para escolher outro."));
                targets.remove(entry.getKey());
                continue;
            }
            updateOne(viewer, target);
        }
    }

    private void updateOne(Player viewer, Player target) {
        if (viewer.getWorld().equals(target.getWorld())) {
            viewer.setCompassTarget(target.getLocation());
            viewer.sendActionBar(Component.text("Rastreando: " + target.getName()));
        } else {
            viewer.sendActionBar(Component.text("Jogador em outro mundo: " + target.getName()));
        }
    }

    @Override
    public void onDisable() {
        targets.clear();
        maceCooldown.clear();
        disguises.clear();
        originalDisplayNames.clear();
        originalTabNames.clear();
    }
}
