rootProject.name = "CreativeSquad4Paper"
