# CreativeSquad4Paper

Plugin de exemplo para servidores **Paper 26.3** (Minecraft Java), feito com Java 25.

## Conteudo
- 13 itens/grupos lendarios implementados, incluindo os capacetes dos gemeos como um unico item.
- Itens identificados por PersistentDataContainer (nao basta renomear um item comum).
- Habilidades ativadas com clique direito.
- Recarga individual por jogador e por item.
- Comandos administrativos e tab-complete.

## IDs
`batata_bobo`, `bota`, `bussola`, `capacetes_gemeos`, `dragao`,
`escudo`, `espada_cacador`, `lampiao`, `pena`, `picareta`, `pocao`, `relogio`, `tridente`.

Os capacetes dos gemeos aparecem como um unico item/grupo para manter exatamente os 13 itens solicitados.

## Compilar
Requisitos: JDK 25 e Gradle 9 ou compativel.

Na pasta do projeto:
```bash
gradle build
```
O arquivo gerado fica em `build/libs/CreativeSquad4Paper-1.0.0.jar`.

## Instalar
1. Pare o servidor.
2. Copie o JAR para a pasta `plugins/`.
3. Inicie o Paper 26.3.
4. Use `/cs list`.
5. Use `/cs give <jogador> <id>` para entregar um item.

## Observacoes
- Este projeto e um ponto de partida jogavel; as habilidades sao implementacoes originais/inspiradas, nao uma garantia de reproduzir exatamente cada poder mostrado na serie.
- Os itens usam materiais vanilla e nomes/lore personalizados. Um resource pack seria necessario para modelos e texturas exclusivas.
- Teste primeiro em um servidor de desenvolvimento e faca backup do mundo.


## Compilar pelo celular (sem instalar Java)
Este projeto inclui GitHub Actions em `.github/workflows/build.yml`.

1. No navegador do celular, crie um repositório vazio no GitHub.
2. Extraia este ZIP no celular e envie **os arquivos e pastas de dentro** do projeto para o repositório (inclua a pasta `.github`).
3. Abra a aba **Actions** do repositório.
4. Abra **Build CreativeSquad4 plugin** e aguarde terminar com marca verde.
5. Entre na execução concluída, baixe o artefato **CreativeSquad4Paper-JAR** e extraia o ZIP baixado.
6. Envie o arquivo `CreativeSquad4Paper-1.0.0.jar` para a pasta `plugins` no painel ShulkerBoxes e reinicie o servidor.

Se o GitHub mostrar falha vermelha, abra o log e compartilhe o texto/print do erro para corrigir. Não envie o ZIP do código-fonte para `plugins`: o servidor precisa do `.jar` compilado.
