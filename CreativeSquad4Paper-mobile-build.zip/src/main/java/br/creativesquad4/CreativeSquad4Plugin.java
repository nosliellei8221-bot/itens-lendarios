package br.creativesquad4;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public final class CreativeSquad4Plugin extends JavaPlugin implements Listener, TabExecutor {
    private NamespacedKey itemKey;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    private record Legendary(String id, String name, Material material, String lore, int cooldown) {}

    private final List<Legendary> items = List.of(
        new Legendary("batata_bobo", "Batata do Bobo", Material.POISONOUS_POTATO, "Uma batata lendaria cheia de surpresas.", 25),
        new Legendary("bota", "Bota Lendaria", Material.DIAMOND_BOOTS, "Impulso veloz e salto aprimorado.", 18),
        new Legendary("bussola", "Bussola Lendaria", Material.COMPASS, "Ajuda a encontrar o ponto de renascimento.", 8),
        new Legendary("capacetes_gemeos", "Capacetes Lendarios dos Gemeos", Material.TURTLE_HELMET, "O poder combinado dos capacetes dos gemeos.", 30),
        new Legendary("dragao", "Dragao Lendario", Material.DRAGON_EGG, "Invoca um companheiro dragao decorativo.", 90),
        new Legendary("escudo", "Escudo Lendario", Material.SHIELD, "Uma barreira temporaria de protecao.", 35),
        new Legendary("espada_cacador", "Espada do Cacador", Material.DIAMOND_SWORD, "Uma lamina lendaria para desafios do jogo.", 20),
        new Legendary("lampiao", "Lampiao Lendario", Material.SOUL_LANTERN, "Ilumina o caminho ao redor.", 15),
        new Legendary("pena", "Pena Lendaria", Material.FEATHER, "Permite planar suavemente.", 25),
        new Legendary("picareta", "Picareta Lendaria", Material.DIAMOND_PICKAXE, "Acelera a mineracao por um curto periodo.", 30),
        new Legendary("pocao", "Pocao Lendaria", Material.POTION, "Concede uma combinacao de efeitos positivos.", 45),
        new Legendary("relogio", "Relogio Lendario", Material.CLOCK, "Revela o horario do mundo e concede visao noturna.", 30),
        new Legendary("tridente", "Tridente Lendario", Material.TRIDENT, "Um impulso aquatico para exploracao.", 25)
    );

    @Override
    public void onEnable() {
        itemKey = new NamespacedKey(this, "legendary_item");
        Objects.requireNonNull(getCommand("cs")).setExecutor(this);
        Objects.requireNonNull(getCommand("cs")).setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("CreativeSquad4 carregado com " + items.size() + " itens lendarios.");
    }

    private Legendary find(String id) {
        return items.stream().filter(i -> i.id().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    private ItemStack createItem(Legendary legendary) {
        ItemStack stack = new ItemStack(legendary.material());
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(legendary.name(), NamedTextColor.LIGHT_PURPLE));
        meta.lore(List.of(
            Component.text(legendary.lore(), NamedTextColor.GRAY),
            Component.text("Clique com o botao direito para ativar", NamedTextColor.YELLOW),
            Component.text("Creative Squad 4", NamedTextColor.DARK_PURPLE)
        ));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, legendary.id());
        stack.setItemMeta(meta);
        return stack;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
            sender.sendMessage(Component.text("Itens lendarios disponiveis:", NamedTextColor.GOLD));
            for (Legendary item : items) sender.sendMessage(Component.text("- " + item.id() + " (" + item.name() + ")", NamedTextColor.YELLOW));
            return true;
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            Legendary legendary = find(args[2]);
            if (target == null) {
                sender.sendMessage(Component.text("Jogador nao encontrado ou offline.", NamedTextColor.RED));
                return true;
            }
            if (legendary == null) {
                sender.sendMessage(Component.text("Item desconhecido. Use /cs list.", NamedTextColor.RED));
                return true;
            }
            target.getInventory().addItem(createItem(legendary)).values()
                .forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
            sender.sendMessage(Component.text("Item entregue: " + legendary.name(), NamedTextColor.GREEN));
            return true;
        }
        sender.sendMessage(Component.text("Use /cs list ou /cs give <jogador> <id>", NamedTextColor.YELLOW));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("list", "give");
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return items.stream().map(Legendary::id).toList();
        }
        return Collections.emptyList();
    }

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR &&
            event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;

        ItemStack stack = event.getItem();
        if (stack == null || !stack.hasItemMeta()) return;
        String id = stack.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (id == null) return;

        Player player = event.getPlayer();
        Legendary legendary = find(id);
        if (legendary == null) return;

        long now = System.currentTimeMillis();
        long readyAt = cooldowns.getOrDefault(player.getUniqueId(), Map.of()).getOrDefault(id, 0L);
        if (now < readyAt) {
            player.sendActionBar(Component.text("Recarga: " + ((readyAt - now + 999) / 1000) + "s", NamedTextColor.RED));
            return;
        }

        boolean activated = activate(player, id);
        if (activated) {
            cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                .put(id, now + legendary.cooldown() * 1000L);
            player.sendActionBar(Component.text(legendary.name() + " ativado!", NamedTextColor.LIGHT_PURPLE));
        }
    }

    private boolean activate(Player p, String id) {
        switch (id) {
            case "batata_bobo" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 20 * 12, 1));
                p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation().add(0, 1, 0), 25, .5, .7, .5, .05);
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_YES, 1, 1.4f);
            }
            case "bota" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 10, 2));
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 20 * 10, 1));
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 20, .4, .1, .4, .08);
            }
            case "bussola" -> {
                Location bed = p.getBedSpawnLocation();
                Location target = bed != null ? bed : p.getWorld().getSpawnLocation();
                p.sendMessage(Component.text("Seu ponto de referencia: " +
                    target.getBlockX() + ", " + target.getBlockY() + ", " + target.getBlockZ(), NamedTextColor.AQUA));
                p.setCompassTarget(target);
            }
            case "capacetes_gemeos" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 25, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 20 * 25, 0));
            }
            case "dragao" -> {
                ArmorStand dragon = (ArmorStand) p.getWorld().spawnEntity(p.getLocation().add(0, 1, 0), EntityType.ARMOR_STAND);
                dragon.customName(Component.text("Dragao Lendario", NamedTextColor.LIGHT_PURPLE));
                dragon.setCustomNameVisible(true);
                dragon.setSmall(true);
                dragon.setInvulnerable(true);
                dragon.setGravity(false);
                dragon.setHelmet(new ItemStack(Material.DRAGON_HEAD));
                Bukkit.getScheduler().runTaskLater(this, dragon::remove, 20L * 20);
                p.getWorld().spawnParticle(Particle.DRAGON_BREATH, p.getLocation().add(0, 1, 0), 35, .8, .5, .8, .03);
            }
            case "escudo" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 20 * 8, 3));
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 20 * 8, 2));
                p.getWorld().spawnParticle(Particle.WAX_ON, p.getLocation().add(0, 1, 0), 30, .8, .8, .8, .1);
            }
            case "espada_cacador" -> {
                // Habilidade de exploracao: revela entidades proximas sem alterar dano.
                p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 20 * 8, 0));
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 24, 2, 1, 2, .03);
            }
            case "lampiao" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 30, 0));
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 35, 1.2, .8, 1.2, .02);
            }
            case "pena" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 20 * 12, 0));
                Vector v = p.getVelocity();
                p.setVelocity(v.setY(Math.max(v.getY(), .65)));
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 25, .5, .5, .5, .08);
            }
            case "picareta" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 20 * 18, 2));
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 18, 0));
            }
            case "pocao" -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 8, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 15, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 20 * 20, 1));
                p.getWorld().spawnParticle(Particle.WITCH, p.getLocation().add(0, 1, 0), 30, .5, .8, .5, .05);
            }
            case "relogio" -> {
                p.sendMessage(Component.text("Horario do mundo: " + p.getWorld().getTime() + " ticks", NamedTextColor.GOLD));
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 20 * 20, 0));
            }
            case "tridente" -> {
                // Efeito de exploracao aquatica; nao arremessa o item nem causa dano.
                p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 20 * 20, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 20 * 12, 0));
                p.getWorld().spawnParticle(Particle.BUBBLE, p.getLocation().add(0, 1, 0), 30, .7, .8, .7, .04);
            }
            default -> { return false; }
        }
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, .8f, 1.3f);
        return true;
    }
}
